package api;

public interface Task<T> {
	
	public T execute();

}
