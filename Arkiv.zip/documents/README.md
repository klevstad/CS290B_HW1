# CS290B_HW1

Compile the project: ant

Run the computer: ant runComputer

Run the TSP Client: ant -Dcomputer_ip=128.111.43.22  runTSPClient

Run the MS Client: ant -Dcomputer_ip=128.111.43.22 runMSClient
